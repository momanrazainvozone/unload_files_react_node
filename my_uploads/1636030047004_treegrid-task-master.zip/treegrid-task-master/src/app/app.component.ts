import { Component ,OnInit} from '@angular/core';
import { sampleData } from '../jsontreegriddata';
import { TreeGridComponent, PageService, ColumnChooserService, ToolbarService} from '@syncfusion/ej2-angular-treegrid';
import {PageSettingsModel } from '@syncfusion/ej2-angular-grids';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [ PageService, ColumnChooserService, ToolbarService ]

})
export class AppComponent  implements OnInit {
  title = 'treegrid-task';
  public data: Object[] = [];
  public pageSettings: PageSettingsModel | undefined;
  public toolbar: string[] | undefined;
  
  ngOnInit(): void {
    this.data = sampleData;
    this.pageSettings = { pageSize: 10 };
    this.toolbar = ['ColumnChooser'];
  }
}
